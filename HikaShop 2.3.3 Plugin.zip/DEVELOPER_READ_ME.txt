Disclaimer: PaymentSense provides this code as an example of a working integration module. Responsibility for the final implementation, functionality and testing of the module resides with the merchant/merchants website developer.

                                             
THIS DOCUMENT IS FOR DEVELOPERS
-----------------------------------------------------------------------------------------------
----HIKASHOP-VERSION-2.2.0---------------------------------------------------------------------
STEP ONE
---------

Please ensure you collect the following information from your client prior to integrating:

+ Merchant Management System Login Details
+ Merchant Gateway ID
+ Merchant Gateway Password
+ PreSharedKey
+ HashMethod



STEP TWO
---------

A Full integration Guide for HikaShop is located inside the INTEGRATION_DOCUMENT folder. 

The file you need is the INTEGRATION_GUIDE.html

Follow the INTEGRATION_GUIDE to integrate to the PaymentSense Gateway.